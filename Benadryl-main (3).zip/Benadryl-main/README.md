# Benadryl
"Benadryl" is a project I made back in June (I'm elpapu writing this). Many users were involved in the development, such as pathos, vii, ablue and wok1337. It contains a lot of features, and a lot of work has been put into it. The source code is going public because a member of the development team decided to leak it, so I'll just ask Aqua to upload it for me before the user leaks it.


## Features
### Stealer
- Minecraft Accounts
  - Lunar
  - LabyMod
  - Impact
  - Meteor
  - Badlion
  - PolyMC
  - Feather
  - Prism
  - Technic
  - In Game Account Switcher 
- Cold Wallets
  - Zcash
  - Armory
  - Bytecoin
  - Ethereum
  - Electrum
  - AtomicWallet
  - Guarda
  - Coinomi
- Discord Token & Injection (credits to itzgonza1337 4 Injection)
- Epic Games 
- Steam
- FileZilla
### Additional
- AntiDump & AntiVM
- Registry Persistence
- Validates found discord tokens before sending
- 0/64 VT 
## Development Team

- [@elpapu](https://github.com/skiesup) (head of the rat)
- [@vii](https://github.com/violettowo) (helped on rat structure)
- [@ablue](https://github.com/AquaNot) (backend team)
- [@wok1337](https://github.com/wokonly) (backend team)
- @pathos (teaching me java)


## Message from Aqua_Not
Anti Benadryl coming soon to stop this rat from being used maliciously :)
And Francium was never a rat stop spreading fake shit, Love from Aqua and Anti Benadryl devs.

## Thanks to everyone.

Thanks to everyone who has helped me on this journey since February. It has been a lot of fun ratting little kids (I'm elpapu speaking, not Aqua lol). I've learned a lot during this time from my friends. It has been a good year for me, but I think it's time to move on, so I'll quit ratting since it's not the same anymore. new gens skidded my rat, so I think it's time to make it public. I hope whoever is reading this will be responsible for the use given to this project. Shoutout to pathos, vii, didi, aqua, body, zkamado_, maticrics, and ynn\_(even if wok leaked this lol). 

## Note

I am not responsible for any damages this software may cause after being acquired. This software was made for personal education and sandbox testing.
