build.gradle ln: 38
mixin ln: 5

change project structure SDK
change gradlew wrapper