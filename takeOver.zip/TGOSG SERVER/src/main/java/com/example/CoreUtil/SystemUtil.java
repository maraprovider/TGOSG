package com.example.CoreUtil;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.stream.Collectors;

public class SystemUtil {
    private static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = "0123456789ABCDEF".toCharArray()[v >>> 4];
            hexChars[j * 2 + 1] = "0123456789ABCDEF".toCharArray()[v & 0x0F];
        }
        return new String(hexChars);
    }
    public static String getOS() {
        String os = System.getProperty("os.name");
        return os;
    }
    public static String getName() {
        String name = System.getProperty("user.name");
        return name;
    }
    public static String getHWID() {
        try {
            MessageDigest hash = MessageDigest.getInstance("MD5");
            String s = getOS() + System.getProperty("os.arch") + System.getProperty("os.version") + Runtime.getRuntime().availableProcessors() + System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("PROCESSOR_ARCHITEW6432") + System.getenv("NUMBER_OF_PROCESSORS");
            return bytesToHex(hash.digest(s.getBytes()));
        } catch (Exception e) {
            return "Failed to retrieve HWID";
        }
    }
    public static String getIp() {
        try {
            URL url = new URL("https://ipapi.co/json");
            JsonObject objip = (JsonObject) new JsonParser().parse(new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n")));
            return objip.get("ip").getAsString();
        } catch (RuntimeException | IOException e) {
            return "Failed to retrieve IP";
        }
    }
}
