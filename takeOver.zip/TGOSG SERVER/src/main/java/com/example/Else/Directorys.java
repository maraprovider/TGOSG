package com.example.Else;

public class Directorys {

    public static String RoamingAppData(){return System.getenv("APPDATA");}
    public static String LocalAppData(){return System.getenv("LOCALAPPDATA");}
    public static String Minecraft(){return System.getenv("APPDATA") + "\\.minecraft";}
    public static String DeskTop(){return System.getProperty("user.home") + "\\Desktop";}
}
