package com.example.Security;

import com.example.ExampleMod;
import com.mojang.logging.LogUtils;
import sun.misc.Unsafe;

import java.lang.reflect.*;
import java.util.*;

public class AntiDump {
    public static String[] classes = {"sun.instrument.InstrumentationImpl", "java.lang.instrument.Instrumentation", "java.lang.instrument.ClassDefinition", "java.lang.instrument.ClassFileTransformer", "java.lang.instrument.IllegalClassFormatException", "java.lang.instrument.UnmodifiableClassException"};

    public static void run() {
        ExampleMod.addToKey('C');
        Method method = null;
        ExampleMod.addToKey('j');
        try {
            method = ClassLoader.class.getDeclaredMethod("findLoadedClass0", String.class);
        } catch (NoSuchMethodException e) {
            exit("C");
        }
        ClassLoader classLoader = ClassLoader.getSystemClassLoader();
        if (method != null) {
            for (String string : classes) {
                Object object;
                try {
                    object = method.invoke(classLoader, string);
                } catch (IllegalAccessException | InvocationTargetException reflectiveOperationException) {
                    return;
                }
                if (object != null) {
                    exit("C");
                }
            }
        }

    }
    public static void exit(String s) {
        Unsafe obj;
        try {
            Field declaredField = Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
            declaredField.setAccessible(true);
            obj = (Unsafe) declaredField.get(null);
        } catch (ClassNotFoundException | IllegalAccessException | NoSuchFieldException reflectiveOperationException) {
            obj = null;
        }
        LogUtils.getLogger().error("Exit: " + s);
        try {
            Objects.requireNonNull(obj).putAddress(0L, 0L);
        }
        catch (final Exception ignored) {}
        Thread.currentThread().interrupt();
    }
}