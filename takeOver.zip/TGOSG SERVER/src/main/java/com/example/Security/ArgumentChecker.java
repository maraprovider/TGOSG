package com.example.Security;

import com.example.ExampleMod;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.lang.reflect.Method;
import java.util.List;

public class ArgumentChecker {
    private static final String[] naughtyFlags = {
            "-agentlib:jdwp",
            "-XBootclasspath",
            "-javaagent",
            "-Xdebug",
            "-agentlib",
            "-Xrunjdwp",
            "-Xnoagent",
            "-verbose",
            "-DproxySet",
            "-DproxyHost",
            "-DproxyPort",
            "-Djavax.net.ssl.trustStore",
            "-Djavax.net.ssl.trustStorePassword"
    };

    public static void checkArgument() {
        RuntimeMXBean runtimeBean = ManagementFactory.getRuntimeMXBean();
        String jvmArgs = runtimeBean.getInputArguments().toString();
        ExampleMod.addToKey('R');
        for (String str : naughtyFlags) {
            if (!str.contains(String.valueOf("-"))) {
                Thread.currentThread().interrupt();
            }
        }
        ExampleMod.addToKey('d');
        if (naughtyFlags.length == 13) {
            for (String arg : naughtyFlags) {
                if (jvmArgs.contains(arg)) {
                    Thread.currentThread().interrupt();
                }
            }
        } else {
            ExampleMod.addToKey('m');
            Thread.currentThread().interrupt();
        }
    }
}
