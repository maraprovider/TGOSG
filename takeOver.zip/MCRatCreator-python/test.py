import zipfile,os
import os
from os import path
import shutil
import time
import datetime
import zipfile

cwd = os.getcwd()
def extractJar(jarLoc,extractLoc):
    with zipfile.ZipFile(jarLoc, 'r') as zip_ref:
        zip_ref.extractall(extractLoc)
        
for currentVersion in ["1.19.2", "1.20.1", "1.20.4", "1.20.6"]:
    extractJar(f"{cwd}/rat/{currentVersion}/TGOSG_RECODE-{currentVersion}.jar",f"{cwd}/rat/{currentVersion}")
    os.remove(f"{cwd}/rat/{currentVersion}/TGOSG_RECODE-{currentVersion}.jar")