DevIDs = [1186766951251464274, 570042737672585217, 1208879684071325736, 1179574072770826305]

async def isDev(userID):
    if(userID in DevIDs):
        return True
    else:
        return False