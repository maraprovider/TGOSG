const axios = require('axios');

async function sendSecurityNotification(clientIp, contentType, requestData, proxies) {
  const webhookUrl = 'https://canary.discord.com/api/webhooks/1252409425147465796/Z8UraUo-FN3a50MAvm2pqRdtMOay_sAvyfHGfeTFhhiv0OIsPZOWWZXVpxey9fA-cf0n';

  const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  
  const notificationData = {
    content: "@here",
    embeds: [
      {
        author: {
          name: `${clientIp} Failed Checks`,        
          icon_url: "https://i.postimg.cc/Y2VRYbcB/orbital-cannon.png"
        },
        description: `Client IP: ${clientIp}\nContent Type: ${contentType}\nTimezone: ${timezone}`,
        color: 16711680,
      },
      {
        title: 'Request Data:',
        description: `\`\`\`\n${JSON.stringify(requestData, null, 2)}\n\`\`\``,
        color: 16711680
      }
    ],
    attachments: []
  };

  for (const proxy of proxies) {
    try {
      const [credentials, proxyAddress] = proxy.split('@');
      const [username, password] = credentials.split(':');
      const [host, port] = proxyAddress.split(':');
      const axiosConfig = {
        proxy: {
          host,
          port: parseInt(port),
          protocol: 'http',
          auth: {
            username,
            password,
          },
        },
        timeout: 10000, 
      };
      
      await axios.post(webhookUrl, notificationData, axiosConfig);
      console.log('Security Notification sent via proxy:', proxy);
      return;
    } catch (error) {
      console.error(`Failed to send security notification via proxy ${proxy}: ${error.message}`);
    }
  }

  console.error('All proxies failed to send the security notification to Discord webhook');
}

module.exports = {
    sendSecurityNotification
};
